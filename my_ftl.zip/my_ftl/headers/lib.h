/*
** lib.h for  in /Users/Winda/Desktop/my_ftl/headers
** 
** Made by AZIS Widad
** Login   <azis_w@etna-alternance.net>
** 
** Started on  Mon Nov  6 11:19:59 2017 AZIS Widad
** Last update Mon Nov  6 12:09:59 2017 AZIS Widad
*/
#ifndef _LIB_H_
# define _LIB_H_

void			my_putchar(char c);
void			my_putstr(char *str);
void			my_put_nbr(int n);
int				my_strlen(const char *str);
char			*my_strdup(const char *str);

#endif /* !_LIB_H_ */
